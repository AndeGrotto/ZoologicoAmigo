package br.upf.ZoologicoAmigo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoologicoAmigoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZoologicoAmigoApplication.class, args);
	}

}
