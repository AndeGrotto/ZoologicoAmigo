INSERT INTO tb_user(nome, usuario, senha) VALUES('Anderson Grotto', 'anderson', '123');
INSERT INTO tb_user(nome, usuario, senha) VALUES('Jeangrei Veiga', 'jeangrei', '123');
INSERT INTO tb_user(nome, usuario, senha) VALUES('Administrador', 'admin', 'admin');


INSERT INTO tb_especie(nome, comida, habitat) VALUES('Mamífero', 'Pasto', 'Pastagem');
INSERT INTO tb_especie(nome, comida, habitat) VALUES('Mamífero', 'Milho', 'Chiqueiro');
INSERT INTO tb_especie(nome, comida, habitat) VALUES('Mamífero', 'Banana', 'Savana');
INSERT INTO tb_especie(nome, comida, habitat) VALUES('Anfíbio', 'Besouro', 'Pesqueira');


INSERT INTO tb_animal(especie_id, nome, sexo, dataNascimento, peso, altura) VALUES(1, 'Vaca', 'F', '2016-02-28T23:15', 728.20, 2.20);
INSERT INTO tb_animal(especie_id, nome, sexo, dataNascimento, peso, altura) VALUES(2, 'Porco', 'M', '2020-12-15T01:32', 46.32, 1.05);
INSERT INTO tb_animal(especie_id, nome, sexo, dataNascimento, peso, altura) VALUES(3, 'Macaco', 'M', '2014-01-07T14:55', 6.47, 1.13);
INSERT INTO tb_animal(especie_id, nome, sexo, dataNascimento, peso, altura) VALUES(4, 'Sapo', 'M', '2021-07-12T17:10', 1.10, 0.30);


